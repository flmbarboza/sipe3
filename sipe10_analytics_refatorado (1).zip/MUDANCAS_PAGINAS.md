# Guia de Migração — Analytics Refatorado

## 📁 Arquivos que você deve substituir

1. **Toda a pasta `analytics/`** → use os novos arquivos fornecidos
2. **`utils/analytics.py`** → substitua pelo novo (compatibilidade)
3. **`utils/google_sheets_exporter.py`** → pode remover (não é mais usado)
4. **`utils/chat.py`** → adicione tracking de chat (ver abaixo)

---

## 🔄 Mudanças em cada página

### Padrão de import (substituir em TODAS as páginas)

**ANTES (varia por página):**
```python
from analytics import track
from analytics import Module
from analytics import module_started, module_completed
from analytics import init_page, begin_observation, end_observation
from analytics import EventType
from utils.analytics import UXMonitor
```

**DEPOIS (padrão unificado):**
```python
from analytics import (
    init_page, module_started, module_completed,
    track, begin_observation, end_observation,
    track_ai_request, track_ai_response, track_ai_error,
    track_data_import, track_data_clear, track_data_export,
    track_navigation, track_chat_message, track_error,
    Module, EventType
)
```

---

### 00_🏠_Início.py

**Mudanças:**
1. Remover `from analytics import init_session, update_activity, check_timeout` (não são mais necessários)
2. Adicionar após `st.set_page_config`:
   ```python
   init_page(Module.HOME)
   ```
3. No botão "Salvar dados da empresa", adicionar:
   ```python
   track("empresa_saved", Module.HOME, metadata={"empresa": nome})
   ```
4. No final, antes do `st.switch_page`, adicionar:
   ```python
   track_navigation(Module.HOME, "1_📋_Business_Model_Canvas.py")
   ```

---

### 1_📋_Business_Model_Canvas.py

**Mudanças:**
1. Já tem `init_page(Module.CANVAS)` — manter
2. Já tem `module_started(Module.CANVAS)` — manter
3. **Adicionar tracking quando adiciona item:**
   ```python
   if st.button("➕ Adicionar outro item", ...):
       st.session_state[session_key].append(new_user_item())
       track("item_added", Module.CANVAS, metadata={"block": chave})
       st.rerun()
   ```
4. **Adicionar tracking quando remove item:**
   ```python
   if indice_remover is not None:
       st.session_state[session_key] = [...]
       track("item_removed", Module.CANVAS, metadata={"block": chave, "item_id": indice_remover})
       st.rerun()
   ```
5. **No botão "Gerar sugestões" (IA):**
   ```python
   if gerar_sugestao:
       track_ai_request(Module.CANVAS, metadata={"block": chave})
       # ... código da IA ...
       # no sucesso:
       track_ai_response(Module.CANVAS, success=True, items_count=adicionados, metadata={"block": chave})
       # no except:
       track_ai_error(Module.CANVAS, str(e), metadata={"block": chave})
   ```
6. **Navegação entre etapas:**
   ```python
   if st.button("Próxima etapa do Canvas"):
       track_navigation(Module.CANVAS, "next_bmc_step")
       st.session_state.bmc_etapa += 1
       st.rerun()
   ```
7. **Finalizar Canvas:**
   ```python
   if st.button("🎉 Finalizar Canvas"):
       module_completed(Module.CANVAS, metadata={"completed_blocks": 9})
       st.session_state.bmc_finalizado = True
       st.rerun()
   ```
8. **Exportações:**
   ```python
   st.download_button(...)  # JSON
   track_data_export(Module.CANVAS, "json")

   st.download_button(...)  # HTML
   track_data_export(Module.CANVAS, "html")
   ```

---

### 2_🌍_Análise_PESTEL.py

**Mudanças:**
1. `module_started(Module.PESTEL)` — já existe
2. **Sugerir por categoria (IA):**
   ```python
   if st.button(f"🤖 Sugerir para {cat}"):
       track_ai_request(Module.PESTEL, metadata={"category": cat})
       resultado = gerar_pestel_ia(cat)
       if resultado:
           track_ai_response(Module.PESTEL, success=True, items_count=adicionados, metadata={"category": cat})
       else:
           track_ai_error(Module.PESTEL, "sem_resultado", metadata={"category": cat})
   ```
3. **Limpar categoria:**
   ```python
   if st.button(f"🗑️", key=f"limpar_pestel_{cat}"):
       track_data_clear(Module.PESTEL, target=cat)
       data["pestel"][cat] = []
       st.rerun()
   ```
4. **Gerar PESTEL completo:**
   ```python
   if st.button("🔄 Gerar PESTEL Completo"):
       track_ai_request(Module.PESTEL, metadata={"scope": "full"})
       resultado = gerar_pestel_ia()
       if resultado:
           track_ai_response(Module.PESTEL, success=True, items_count=total_adicionados, metadata={"scope": "full"})
   ```
5. **Limpar PESTEL:**
   ```python
   if st.button("🗑️ Limpar PESTEL"):
       track_data_clear(Module.PESTEL, target="all_categories")
       for cat in CATEGORIAS.keys():
           data["pestel"][cat] = []
       st.rerun()
   ```

---

### 3_⚔️_5_Forças_de_Porter.py

**Mudanças:**
1. `module_started(Module.PORTER)` — já existe
2. **Gerar análise completa:**
   ```python
   if st.button("🔄 Gerar Análise Completa"):
       track_ai_request(Module.PORTER, metadata={"scope": "full"})
       resultado = gerar_analise_ia()
       if resultado:
           track_ai_response(Module.PORTER, success=True, items_count=5, metadata={"scope": "full"})
   ```
3. **Sugerir por força:**
   ```python
   if st.button(f"🤖 Sugerir", key=f"sugerir_porter_{forca['id']}"):
       track_ai_request(Module.PORTER, metadata={"force": forca['id']})
       resultado = gerar_analise_ia(forca["id"])
       if resultado:
           track_ai_response(Module.PORTER, success=True, items_count=1, metadata={"force": forca['id']})
   ```
4. **Limpar por força:**
   ```python
   if st.button(f"🗑️ Limpar", key=f"limpar_porter_{forca['id']}"):
       track_data_clear(Module.PORTER, target=forca['id'])
       data["porter_analise"][forca["id"]] = {"intensidade": 3, "notas": ""}
       st.rerun()
   ```
5. **Limpar análise completa:**
   ```python
   if st.button("🗑️ Limpar Análise"):
       track_data_clear(Module.PORTER, target="all_forces")
       for forca in FORCAS:
           data["porter_analise"][forca["id"]] = {"intensidade": 3, "notas": ""}
       st.rerun()
   ```

---

### 4_🎯_Análise_SWOT.py

**Mudanças:**
1. `module_started(Module.SWOT)` — já existe
2. **Importar de PESTEL:**
   ```python
   if st.button("⬇️ Importar Oportunidades da Análise PESTEL"):
       novas = itens_pestel_por_tipo("Oportunidade")
       track_data_import(Module.SWOT, source_module="pestel", items_count=len(novas), metadata={"type": "oportunidades"})
       # ... resto do código
   ```
3. **Importar ameaças:**
   ```python
   if st.button("⬇️ Importar Ameaças do PESTEL + Porter"):
       novas = itens_pestel_por_tipo("Ameaça") + itens_porter_alerta()
       track_data_import(Module.SWOT, source_module="pestel_porter", items_count=len(novas), metadata={"type": "ameacas"})
   ```
4. **Gerar SWOT completa:**
   ```python
   if st.button("🔄 Gerar SWOT Completa"):
       track_ai_request(Module.SWOT, metadata={"scope": "full"})
       resultado = gerar_analise_swot()
       if resultado:
           track_ai_response(Module.SWOT, success=True, items_count=total_adicionados, metadata={"scope": "full"})
   ```
5. **Sugerir por quadrante:**
   ```python
   if st.button(f"🤖 Sugerir", key=f"sugerir_{chave}"):
       track_ai_request(Module.SWOT, metadata={"quadrant": chave})
       resultado = gerar_analise_swot(chave)
       if resultado:
           track_ai_response(Module.SWOT, success=True, items_count=adicionados, metadata={"quadrant": chave})
   ```
6. **Limpar por quadrante:**
   ```python
   if st.button(f"🗑️", key=f"limpar_{chave}"):
       track_data_clear(Module.SWOT, target=chave)
       data["swot"][chave] = []
       st.rerun()
   ```
7. **Limpar SWOT completa:**
   ```python
   if st.button("🗑️ Limpar SWOT"):
       track_data_clear(Module.SWOT, target="all_quadrants")
       for chave, _, _ in QUADRANTES:
           data["swot"][chave] = []
       st.rerun()
   ```

---

### 5_🧭_Planejamento_Estratégico.py

**Mudanças:**
1. `module_started(Module.PLANEJAMENTO)` — já existe
2. **Sugerir Missão:**
   ```python
   if st.button("🤖 Sugerir Missão"):
       track_ai_request(Module.PLANEJAMENTO, metadata={"field": "missao"})
       resultado = gerar_missao_ia()
       if resultado:
           track_ai_response(Module.PLANEJAMENTO, success=True, metadata={"field": "missao"})
   ```
3. **Sugerir Visão:**
   ```python
   if st.button("🤖 Sugerir Visão"):
       track_ai_request(Module.PLANEJAMENTO, metadata={"field": "visao"})
       resultado = gerar_visao_ia()
       if resultado:
           track_ai_response(Module.PLANEJAMENTO, success=True, metadata={"field": "visao"})
   ```
4. **Sugerir Valores:**
   ```python
   if st.button("🤖 Sugerir Valores"):
       track_ai_request(Module.PLANEJAMENTO, metadata={"field": "valores"})
       resultado = gerar_valores_ia()
       if resultado:
           track_ai_response(Module.PLANEJAMENTO, success=True, metadata={"field": "valores"})
   ```
5. **Gerar SWOT Cruzada:**
   ```python
   if st.button("🔄 Gerar SWOT Cruzada"):
       track_ai_request(Module.PLANEJAMENTO, metadata={"field": "swot_cruzada", "scope": "full"})
       resultado = gerar_swot_cruzada()
       if resultado:
           track_ai_response(Module.PLANEJAMENTO, success=True, metadata={"field": "swot_cruzada", "scope": "full"})
   ```
6. **Sugerir SWOT Cruzada por quadrante:**
   ```python
   if st.button(f"🤖 Sugerir", key=f"sugerir_cruz_{chave}"):
       track_ai_request(Module.PLANEJAMENTO, metadata={"field": "swot_cruzada", "quadrant": chave})
       resultado = gerar_swot_cruzada(chave)
       if resultado:
           track_ai_response(Module.PLANEJAMENTO, success=True, metadata={"field": "swot_cruzada", "quadrant": chave})
   ```
7. **Limpar SWOT Cruzada:**
   ```python
   if st.button("🗑️ Limpar SWOT Cruzada"):
       track_data_clear(Module.PLANEJAMENTO, target="swot_cruzada")
       for chave, _, _ in QUADRANTES_CRUZ:
           data["swot_cruzada"][chave] = []
       st.rerun()
   ```
8. **Gerar Objetivos:**
   ```python
   if st.button("🔄 Gerar Objetivos"):
       track_ai_request(Module.PLANEJAMENTO, metadata={"field": "objetivos"})
       resultado = gerar_objetivos()
       if resultado:
           track_ai_response(Module.PLANEJAMENTO, success=True, items_count=adicionados, metadata={"field": "objetivos"})
   ```
9. **Limpar Objetivos:**
   ```python
   if st.button("🗑️ Limpar Objetivos"):
       track_data_clear(Module.PLANEJAMENTO, target="objetivos")
       data["objetivos"] = []
       st.rerun()
   ```

---

### 6_✅_Plano_de_Ação_5W2H.py

**Mudanças:**
1. `module_started(Module.PLANO_ACAO)` — já existe
2. **Gerar Plano com IA:**
   ```python
   if gerar_plano:
       if not objetivos:
           st.warning("...")
       else:
           track_ai_request(Module.PLANO_ACAO, metadata={"scope": "full_plan"})
           # ... código da IA ...
           # no sucesso:
           track_ai_response(Module.PLANO_ACAO, success=True, items_count=len(acoes_adicionadas), metadata={"scope": "full_plan"})
           # no except:
           track_ai_error(Module.PLANO_ACAO, str(e), metadata={"scope": "full_plan"})
   ```
3. **Limpar Plano:**
   ```python
   if limpar_plano:
       track_data_clear(Module.PLANO_ACAO, target="all_actions")
       data["acao_5w2h"] = []
       st.rerun()
   ```
4. **Exportar CSV:**
   ```python
   st.download_button("⬇️ Baixar CSV", ...)
   track_data_export(Module.PLANO_ACAO, "csv")
   ```

---

### 7_📋_Planos_por_Função.py

**Mudanças:**
1. **Remover:**
   ```python
   from utils.analytics import UXMonitor
   monitor = UXMonitor()
   page_name = "Planos Departamentais"
   monitor.track_event('page_view', page_name)
   ```
2. **Manter:**
   ```python
   from analytics import Module, module_started
   module_started(Module.PLANO_FUNCAO)
   ```
3. **Sugerir Plano por departamento:**
   ```python
   if st.button(f"🤖 Sugerir Plano", key=f"ia_{depto}"):
       track_ai_request(Module.PLANO_FUNCAO, metadata={"department": depto})
       resultado = gerar_plano_departamento_ia(depto)
       if resultado:
           track_ai_response(Module.PLANO_FUNCAO, success=True, metadata={"department": depto})
   ```

---

### 8_💰_Orçamento.py

**Mudanças:**
1. `module_started(Module.FINANCEIRO)` — já existe
2. Não há IA nesta página, mas adicione tracking se houver exportações futuras.

---

### 9_🛃_Monitoramento.py

**Mudanças:**
1. `module_started(Module.MONITORAMENTO)` — já existe
2. **Gerar Relatório Executivo:**
   ```python
   if st.button("🤖 Gerar Relatório Executivo"):
       track_ai_request(Module.MONITORAMENTO, metadata={"report_type": "executive"})
       # ... código da IA ...
       # no sucesso:
       track_ai_response(Module.MONITORAMENTO, success=True, metadata={"report_type": "executive"})
       # no except:
       track_ai_error(Module.MONITORAMENTO, str(e), metadata={"report_type": "executive"})
   ```

---

### 10_🔄_Revisão.py

**Mudanças:**
1. `module_started(Module.REVIEW)` — já existe
2. **Revisar Estratégia (IA):**
   ```python
   if st.button("🤖 Revisar Estratégia"):
       track_ai_request(Module.REVIEW, metadata={"scope": "full_review"})
       resultado = gerar_revisao_ia()
       if resultado:
           track_ai_response(Module.REVIEW, success=True, metadata={"scope": "full_review"})
   ```
3. **Aplicar Recomendações:**
   ```python
   if st.button("Aplicar Recomendações"):
       track("recommendations_applied", Module.REVIEW, metadata={"opportunities": len(resultado.get("novas_oportunidades", [])), "risks": len(resultado.get("novos_riscos", []))})
   ```
4. **Salvar Revisão:**
   ```python
   if st.button("📌 Salvar Revisão Atual"):
       track("revision_saved", Module.REVIEW, metadata={"resultados": len(data["revisao"].get("resultados", []))})
   ```

---

### 11_📈_Painel_de_Controle.py

**Mudanças:**
1. `module_started(Module.PAINEL)` — já existe
2. **Gerar Insights:**
   ```python
   if st.button("🔍 Gerar Insights do Planejamento"):
       track_ai_request(Module.PAINEL, metadata={"scope": "insights"})
       # ... código da IA ...
       # no sucesso:
       track_ai_response(Module.PAINEL, success=True, metadata={"scope": "insights"})
   ```

---

### 12_📄_Relatório_Completo.py

**Mudanças:**
1. `module_started(Module.RELATORIO)` — já existe
2. **Exportações:**
   ```python
   st.download_button("⬇️ Baixar em Markdown (.md)", ...)
   track_data_export(Module.RELATORIO, "markdown")

   st.download_button("🖨️ Imprimir / Salvar como PDF", ...)
   track_data_export(Module.RELATORIO, "html")
   ```
3. **Revisão Completa (IA):**
   ```python
   if st.button("🔍 Executar Revisão Completa do Planejamento"):
       track_ai_request(Module.RELATORIO, metadata={"scope": "full_validation"})
       # ... código da IA ...
       # no sucesso:
       track_ai_response(Module.RELATORIO, success=True, metadata={"scope": "full_validation"})
       # no except:
       track_ai_error(Module.RELATORIO, str(e), metadata={"scope": "full_validation"})
   ```
4. **Limpar Revisão:**
   ```python
   if st.button("🗑️ Limpar Revisão"):
       track_data_clear(Module.RELATORIO, target="ai_review")
       del st.session_state["revisao_ia"]
       st.rerun()
   ```

---

## 🛠️ utils/chat.py — Adicionar tracking de chat

No início do arquivo, adicione:
```python
from analytics import track_chat_message, Module
```

Dentro de `render_chat`, após `if not enviar or not pergunta.strip(): return`, adicione:
```python
# Detecta qual módulo está ativo (baseado na página atual)
page = st.session_state.get("analytics_current_module", "unknown")
track_chat_message(page, metadata={"message_length": len(pergunta)})
```

---

## ✅ Checklist final

- [ ] Substituir pasta `analytics/`
- [ ] Substituir `utils/analytics.py`
- [ ] Remover `utils/google_sheets_exporter.py` (ou deixar, não interfere)
- [ ] Atualizar imports em todas as páginas
- [ ] Adicionar `track_ai_request/response/error` em todos os botões de IA
- [ ] Adicionar `track_data_clear` em todos os botões de limpar
- [ ] Adicionar `track_data_import` nas importações entre páginas
- [ ] Adicionar `track_data_export` nos downloads
- [ ] Adicionar `track_navigation` nos botões de próxima etapa
- [ ] Adicionar `module_completed` nos pontos de conclusão (Canvas, Relatório)
- [ ] Adicionar tracking no `utils/chat.py`

---

## 🧪 Testando

1. Rode o app localmente
2. Acesse o Google Sheets "SIPE10 Analytics"
3. Verifique se os eventos chegam em lotes (máx 20 eventos ou a cada 5s)
4. Desconecte a internet temporariamente, faça ações, reconecte — os eventos devem ser reenviados
5. Verifique se não há duplicatas de `page_view`
